package com.Interface;

public interface Appointment {
	
	
	public void delete_Appointment(String theappid,int id);

}
