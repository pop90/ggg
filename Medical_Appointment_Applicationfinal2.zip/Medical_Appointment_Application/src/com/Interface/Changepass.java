package com.Interface;

public interface Changepass {
	
	public String changePass1(int i,String a,String b);
	

}
