package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.Bean.Appointmentbean;
import com.ConnectionString.ConnectionString;

public class AppointmentCheckDAO extends ConnectionString {
	//
	public List<Appointmentbean> checkAppointment(int did,String date) throws SQLException, FileNotFoundException  
	{
		List<Appointmentbean> al2=new <Appointmentbean>ArrayList();
		//String booked="";
		 Connection con=null;
		PreparedStatement preparedStatement;
		//java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		try {
			
		   // int d_id=Integer.parseInt(did);
			System.out.println(date);
		    con = getConnection();	
			
			String query = "SELECT A_BOOKED,APP_TIME FROM PG_APPOINTMENT_DEMO WHERE D_ID='"+did+"' AND APP_DATE='"+date+"' AND A_BOOKED>=1";
			 
			 preparedStatement = con.prepareStatement(query);
			// preparedStatement.setInt(1, did);
			 //preparedStatement.setString(2,date);
			
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int a_booked = myRs.getInt("A_BOOKED");
				 int time=myRs.getInt("APP_TIME");
				 
				 //if(a_booked==1)
				 //{
					// booked="booked";
				// }
				 Appointmentbean abean = new  Appointmentbean(time,a_booked);

				 
				 al2.add(abean);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return al2;
		
	 }

}
