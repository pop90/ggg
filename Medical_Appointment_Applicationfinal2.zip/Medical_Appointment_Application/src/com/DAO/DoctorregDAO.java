package com.DAO;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import com.Bean.*;
import com.ConnectionString.*;
import com.Other.Encryption;

public class DoctorregDAO extends ConnectionString{
	public String doctorRegister(Doctor registerBean) throws FileNotFoundException
	 {
		 try
		 {
		 int i;
		 Encryption e1=new Encryption();
		 String firstName = registerBean.getDoctor_name();
		 String address = registerBean.getAddress();
		 String gender = registerBean.getGender();
		 String department = registerBean.getDepartment();
		 String email = registerBean.getEmail();
		 String phoneNumber =registerBean.getPhone();
		 String username=registerBean.getUsername();
		 String password=registerBean.getPassword();
		 Connection con = null;
		 PreparedStatement preparedStatement = null;	
		 con = getConnection();
		 String que = "select USERNAME from PG_LOGIN where USERNAME='"+username+"'";
		 preparedStatement = con.prepareStatement(que);	 
		 ResultSet rs1=preparedStatement.executeQuery();
		 String user = null;
		 while(rs1.next())
			{
			 user=rs1.getString("USERNAME");
			}
		 if(user!=null)
		 {
			 return "UAT";
		 }
		 else
		 { 
		 String query = "insert into PG_DOCTOR_REG(D_NAME,D_DEPARTMENT,D_GENDER,D_PHONE,D_EMAIL,D_ADDRESS,D_TYPE) values (?,?,?,?,?,?,1)"; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 preparedStatement.setString(1, firstName);
		 preparedStatement.setString(2, department);
		 preparedStatement.setString(3, gender);
		 preparedStatement.setString(4, phoneNumber);
		 preparedStatement.setString(5, email);
		 preparedStatement.setString(6, address);
		  preparedStatement.executeUpdate();
		
		 String regquery="select max(D_ID) as max from PG_DOCTOR_REG";
		 preparedStatement = con.prepareStatement(regquery);
		 ResultSet rs=preparedStatement.executeQuery();
			int max=0;
			while(rs.next())
			{
				 max=rs.getInt("max");
			}
			//LoginDAO d=new LoginDAO();
			String encpass=e1.caesarCipherEncrypt(password);
			System.out.println("the encrypted password is :"+encpass);
			
			String logquery="insert into PG_LOGIN(USERNAME,PASSWORD,D_ID,L_TYPE) values(?,?,?,1)";
			preparedStatement = con.prepareStatement(logquery); //Making use of prepared statements here to insert bunch of data
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, encpass);
			preparedStatement.setInt(3, max);
			  i=preparedStatement.executeUpdate();
		 }
		 if (i!=0)  //Just to ensure data has been inserted into the database
		return "SUCCESS";
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
			 //System.out.println("an error in program has occured");
		 }
		 
		 return "something went wrong";  // On failure, send a message from here.

	 }
	public String doctorUpdate(Doctor registerBean) throws FileNotFoundException, SQLException
	{
		String firstName = registerBean.getDoctor_name();
		 String address = registerBean.getAddress();
		 String gender = registerBean.getGender();
		 String department = registerBean.getDepartment();
		 String email = registerBean.getEmail();
		 String phoneNumber =registerBean.getPhone();
		 int d_id =registerBean.getId();
		 
		 Connection con = null;
		 PreparedStatement preparedStatement = null;	
		 con = getConnection();
		 String query = "UPDATE PG_DOCTOR_REG SET D_NAME='"+firstName+"',D_DEPARTMENT='"+department+"',D_GENDER='"+gender+"',D_PHONE='"+phoneNumber+"',D_EMAIL='"+email+"',D_ADDRESS='"+address+"' WHERE D_ID='"+d_id+"'"; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 
		  int a=preparedStatement.executeUpdate();
		System.out.println("the updated profile is"+a);
		if( a==1)
		{
			return "SUCCESS";
		}
		else
		{
			return "FAIL";
		}
		
		
	}
	public List<Doctor> listDoctor(int did) throws SQLException, FileNotFoundException 
	{
		
		
		List<Doctor> doc=new <Doctor>ArrayList();
		 Connection con=null;
		PreparedStatement preparedStatement;
		 con = getConnection();	
			
			String query = "SELECT  D_NAME,D_DEPARTMENT,D_GENDER,D_PHONE,D_EMAIL,D_ADDRESS FROM PG_DOCTOR_REG WHERE D_ID='"+did+"' ";
			
			 preparedStatement = con.prepareStatement(query);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				
				 String name = myRs.getString("D_NAME");
				 String department = myRs.getString("D_DEPARTMENT");
				 String gender = myRs.getString("D_GENDER");
				 String phonenum = myRs.getString("D_PHONE");
				 String address = myRs.getString("D_ADDRESS");
				 String email = myRs.getString("D_EMAIL");
				
				
				 
				 Doctor tempDoctor = new Doctor(email,department,gender,phonenum,address,department);

				 
				 doc.add(tempDoctor);				
			                        }
			 myRs.close(); 
			 preparedStatement.close();

			return doc;
			
		
	}
	
}
