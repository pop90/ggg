package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.Bean.*;
import com.ConnectionString.*;
import com.Other.Encryption;
public class PatientregDAO extends ConnectionString {
	public String patientRegister(PatientRegBean objbean) throws FileNotFoundException
	{
		
		try
		{
			Encryption e=new Encryption();
			int i;
		 String firstName = objbean.getName();
		 String address = objbean.getAddress();
		 String gender = objbean.getGender();
		 String email = objbean.getMail();
		 String phoneNumber =objbean.getPhone();
		 String username=objbean.getUsername();
		 String password=objbean.getPassword();
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 con = getConnection();
		 String que = "select USERNAME from PG_LOGIN where USERNAME='"+username+"'";
		 preparedStatement = con.prepareStatement(que);
		 
		 ResultSet rs1=preparedStatement.executeQuery();
		 String user = null;
		 while(rs1.next())
			{
			 user=rs1.getString("USERNAME");
			}
		 if(user!=null)
		 {
			 return "UAT";
		 }
		 else
		 {
		  
		 String query = "insert into PG_PATIENT_REG(P_NAME,P_GENDER,P_PHONE,P_EMAIL,P_ADDRESS,P_TYPE) values (?,?,?,?,?,0)"; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 preparedStatement.setString(1, firstName);
		 preparedStatement.setString(2, gender);
		 preparedStatement.setString(3, phoneNumber);
		 preparedStatement.setString(4, email);
		 preparedStatement.setString(5, address);
		 preparedStatement.executeUpdate();
		 String regquery="select max(P_ID) as max from PG_PATIENT_REG";
		 preparedStatement = con.prepareStatement(regquery);
		 ResultSet rs=preparedStatement.executeQuery();
			int max=0;
			while(rs.next())
			{
				 max=rs.getInt("max");
			}
			//LoginDAO d=new LoginDAO();
			String encpass=e.caesarCipherEncrypt(password);
			System.out.println("the password is:"+encpass);
		    String logquery="insert into PG_LOGIN(USERNAME,PASSWORD,P_ID,L_TYPE) values(?,?,?,0)";
			preparedStatement = con.prepareStatement(logquery); //Making use of prepared statements here to insert bunch of data
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, encpass);
			preparedStatement.setInt(3, max);
			  i=preparedStatement.executeUpdate();
		 }
		 if (i!=0)  //Just to ensure data has been inserted into the database
		return "SUCCESS";
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
			 //System.out.println("an error in program has occured");
		 }
		 
		 return "something went wrong";  // On failure, send a message from here.

		
	}
	public String patientUpdate(PatientRegBean objbean) throws FileNotFoundException, SQLException
	{
		String firstName = objbean.getName();
		 String address = objbean.getAddress();
		 String gender = objbean.getGender();
		 String email = objbean.getMail();
		 String phoneNumber =objbean.getPhone();
		 int p_id =objbean.getId();
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 con = getConnection();
		 String query = "update  PG_PATIENT_REG set P_NAME='"+firstName+"',P_GENDER='"+gender+"',P_PHONE='"+phoneNumber+"',P_EMAIL='"+email+"',P_ADDRESS='"+address+"' where P_ID='"+p_id+"'"; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 int a= preparedStatement.executeUpdate();
		 if( a==1)
			{
				return "SUCCESS";
			}
			else
			{
				return "FAIL";
			}
			
		
	}
	

}
