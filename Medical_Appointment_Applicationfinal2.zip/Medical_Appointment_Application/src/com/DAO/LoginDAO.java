package com.DAO;
import java.io.FileNotFoundException;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import com.Bean.*;
import com.ConnectionString.*;
import com.Other.Encryption;





public class LoginDAO extends ConnectionString {
	public List<PatientRegBean> validateUser(LoginBean objbean) throws FileNotFoundException  {
		PatientRegBean objPatientRegBean=new PatientRegBean();
		// TODO Auto-generated method stub
		String userName = objbean.getUsername(); //Keeping user entered values in temporary variables.
		String password = objbean.getPassword();
		List<PatientRegBean> list=new ArrayList<PatientRegBean>();
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		 int i=0;
		String userNameDB = "";
		String passwordDB = "";
		int typeDB=0;
		int pDB;
		Encryption e1=new Encryption();
		try
		{
			objPatientRegBean.setUsertype("inavalid");
			con = getConnection();
			statement = con.createStatement();
			
			resultSet = statement.executeQuery("select username,password,L_TYPE,p_id,d_id,ad_id from PG_LOGIN where username='"+userName+"' ");
			
			while(resultSet.next()) 
			{
				i=i+1;
				System.out.println(resultSet.getString("username"));
				System.out.println(resultSet.getString("password"));
				System.out.println(resultSet.getInt("p_id"));
			
				userNameDB = resultSet.getString("username"); //fetch the values present in database
				passwordDB = resultSet.getString("password");
				String pass=e1.caesarCipherDecrypte(passwordDB);
				System.out.println("the decrypted password is:"+pass);
				typeDB=resultSet.getInt("L_TYPE");
			  
			    objPatientRegBean.setD_id(resultSet.getInt("d_id"));
				System.out.println(resultSet.getInt("p_id"));
				objPatientRegBean.setId(resultSet.getInt("p_id"));
				objPatientRegBean.setAd_id(resultSet.getInt("ad_id"));
				list.add(objPatientRegBean);
				if(userName.equals(userNameDB) && password.equals(pass))
				{
					if(typeDB==0)
					   {
						
						objPatientRegBean.setUsertype("PATIENT");
						   break;
					   }
					   else if(typeDB==1)
					   {
						   objPatientRegBean.setUsertype("DOCTOR");
						   break;
					   }
					   else if(typeDB==2)
					   {
						   objPatientRegBean.setUsertype("ADMIN");
						   break;
					   }
					   
					
				}
				else
				{
					return list;
				}
				
			}
				
			list.add(objPatientRegBean);			

		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return list; // Just returning appropriate message otherwise

	}
	
}
