package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Bean.*;
import com.ConnectionString.ConnectionString;
import com.Other.Encryption;

public class ForgPassDAO  extends ConnectionString{
	public List<ForgPass> getPass(int type,String email) throws SQLException, FileNotFoundException  
	{
		
		List<ForgPass> al2=new <ForgPass>ArrayList();
       
		 Connection con=null;
		PreparedStatement preparedStatement;
		int d_id=0;
		String username="";
		String password="";
		int p_id=0;	
		int valid=0;
		try {
		  if(type==1)
		  {
			Encryption e1=new Encryption();
		    con = getConnection();	
			
			String query = "SELECT D_ID FROM PG_DOCTOR_REG WHERE  D_EMAIL='"+email+"'";
			 
			 preparedStatement = con.prepareStatement(query);
			
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {
		 
				 d_id = myRs.getInt("D_ID");
				 
			                     }
			 if(d_id!=0)
			 {
				 valid=valid+1;
			 }
			 
			 String query2 = "SELECT USERNAME,PASSWORD FROM PG_LOGIN WHERE D_ID='"+d_id+"' ";
			 
			 preparedStatement = con.prepareStatement(query2);
				
			 ResultSet myRs2=preparedStatement.executeQuery();
		
			 while (myRs2.next()) {
				 username = myRs2.getString("USERNAME");
				 password = myRs2.getString("PASSWORD");
				 String pass=e1.caesarCipherDecrypte(password);
				 ForgPass fb=new ForgPass(username,pass);
				 al2.add(fb);			 
	                }
			 
		  }
		  else
		  {
			
		    con = getConnection();	
			
			String query = "SELECT P_ID FROM PG_PATIENT_REG WHERE  D_EMAIL='"+email+"'";
			 
			 preparedStatement = con.prepareStatement(query);
			
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {
		 
				 p_id = myRs.getInt("P_ID");
				 
			                     }
			 
			 String query2 = "SELECT USERNAME,PASSWORD FROM PG_LOGIN WHERE P_ID='"+p_id+"' ";
			 
			 preparedStatement = con.prepareStatement(query2);
				
			 ResultSet myRs2=preparedStatement.executeQuery();
		
			 while (myRs2.next()) {
				 username = myRs2.getString("USERNAME");
				 password = myRs2.getString("PASSWORD");
				 ForgPass fb=new ForgPass(username,password);
				 al2.add(fb);			 
	                }
			 
		  }

		  return al2;		
		
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		return al2;
		
	 }
	

}
