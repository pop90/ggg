package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.Bean.Leave;
import com.ConnectionString.ConnectionString;

public class AdminLeave extends ConnectionString {
	public List<Leave> getLeaveView() throws SQLException
	{
		List<Leave> lv =new <Leave>ArrayList();
		try {
		
		System.out.println("dao1");
		 Connection con=null;
		PreparedStatement preparedStatement;
		
		
			
			System.out.println("2");
			
		    con = getConnection();	
			
			String query = " SELECT LE_ID,D_ID,D_STATUS,A_STATUS,REASON,S_DATE,E_DATE FROM PG_DOCTOR_LEAVE WHERE S_DATE>SYSDATE";
			
			 preparedStatement = con.prepareStatement(query);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int le_id = myRs.getInt("LE_ID");
				 int d_id = myRs.getInt("D_ID");
				 int d_stat = myRs.getInt("D_STATUS");
				 int a_stat = myRs.getInt("A_STATUS");
				 String reason = myRs.getString("REASON");
				 Date sd = myRs.getDate("S_DATE");
				 Date ed = myRs.getDate("E_DATE");
				
				 
				 System.out.println("3");
				 Leave dlv = new Leave(le_id,d_id,d_stat,reason,sd,ed,a_stat);

				 
				 lv.add(dlv);				
			                        }


			 con.close();
			 myRs.close(); 
			 preparedStatement.close();
		
		
		
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
		return lv;	
		
		
	 }
	public void cancelLeave(String le_id) throws FileNotFoundException {

		Connection myConn = null;
		PreparedStatement myStmt1 = null;
		
		try {
			
			int le_id1 = Integer.parseInt(le_id);
			
			
			myConn  = getConnection();	
			
			
			String sql = "UPDATE PG_DOCTOR_LEAVE SET A_STATUS=0 where LE_ID=?";
			
			
			myStmt1 = myConn.prepareStatement(sql);
			myStmt1.setInt(1, le_id1);
			boolean i=myStmt1.execute();
			
			System.out.println("the value of i is :"+i);
			myStmt1.close();
			 myConn.close();
		}
		 catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
	}
	
	public void acceptLeave(String le_id,String did,String s_date,String e_date) throws FileNotFoundException {

		Connection myConn = null;
		PreparedStatement myStmt1 = null;
		
		try {
			
			int le_id1 = Integer.parseInt(le_id);
			int d_id=Integer.parseInt(did);
			
			myConn  = getConnection();	
			
			
			String sql = "UPDATE PG_DOCTOR_LEAVE SET A_STATUS=1 where LE_ID='"+le_id+"'";
			myStmt1 = myConn.prepareStatement(sql);		
			myStmt1.execute();
			
			String sql1 = "UPDATE PG_APPOINTMENT_DEMO SET A_BOOKED=2 WHERE D_ID='"+d_id+"' AND APP_DATE>='"+s_date+"' AND APP_DATE<='"+e_date+"'";
			myStmt1 = myConn.prepareStatement(sql1);		
			myStmt1.execute();
			
			System.out.println("the value of i is :");
			myStmt1.close();
			 myConn.close();
		}
		 catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
	}
	
	
	
	
}
