package com.DAO;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.ConnectionString.*;
import com.Other.Encryption;
import com.Bean.*;


public class DoctorList extends ConnectionString
{
	public List<Doctor> getDoctor() throws SQLException, FileNotFoundException  
	{
		List<Doctor> doc=new <Doctor>ArrayList();
		Encryption e1=new Encryption();
		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		
			
		    con = getConnection();	
			
			String query = "SELECT PG_DOCTOR_REG.D_ID AS ID,PG_DOCTOR_REG.D_NAME AS NAME,PG_DOCTOR_REG.D_DEPARTMENT AS DEPARTMENT,PG_LOGIN.USERNAME AS USERNAME,PG_LOGIN.PASSWORD AS PASSWORD FROM PG_DOCTOR_REG JOIN PG_LOGIN ON PG_DOCTOR_REG.D_ID=PG_LOGIN.D_ID";
			
			 preparedStatement = con.prepareStatement(query);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int id = myRs.getInt("ID");
				 String firstName = myRs.getString("NAME");
				 String department = myRs.getString("DEPARTMENT");
				 String username = myRs.getString("USERNAME");
				 String password = myRs.getString("PASSWORD");
				 String pass=e1.caesarCipherDecrypte(password);
				 
				 Doctor tempDoctor = new Doctor(id,firstName,department,username,pass);

				 
				 doc.add(tempDoctor);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return doc;
		
	 }
	public void deleteDoctor(String theDoctorId,String  username) throws FileNotFoundException {

		Connection myConn = null;
		PreparedStatement myStmt1 = null;
		PreparedStatement myStmt2 = null;
		try {
			
			int doctorId = Integer.parseInt(theDoctorId);
			
			
			myConn  = getConnection();	
			
			
			String sql = "delete  from PG_LOGIN where USERNAME='"+username+"'";
			
			
			myStmt1 = myConn.prepareStatement(sql);
			int f=myStmt1.executeUpdate();
			System.out.println(f);
			myStmt1.close();
			
			
			String sql2 = "UPDATE PG_APPOINTMENT_DEMO SET A_BOOKED=3 WHERE D_ID='"+theDoctorId+"'";
			myStmt2 = myConn.prepareStatement(sql2);
			int i=myStmt2.executeUpdate();
			System.out.println(i);
			
			myStmt2.close();
			 myConn.close();
		}
		 catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
	}
		
 
 }
