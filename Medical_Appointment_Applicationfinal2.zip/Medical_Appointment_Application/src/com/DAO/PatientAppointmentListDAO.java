package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.Bean.Appointmentbean;
import com.ConnectionString.ConnectionString;
import com.Interface.Appointment;

public class PatientAppointmentListDAO extends ConnectionString implements Appointment {
	public List<Appointmentbean> getAppointment(int pid) throws SQLException, FileNotFoundException  
	{
		List<Appointmentbean> al2=new <Appointmentbean>ArrayList();

		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		   // int d_id=Integer.parseInt(did);
			
		    con = getConnection();	
			
			String query = "SELECT A_ID,D_ID,APP_DATE,APP_TIME,A_BOOKED FROM PG_APPOINTMENT_DEMO WHERE P_ID=? AND APP_DATE>=SYSDATE ORDER BY APP_DATE,APP_TIME ASC";
			 
			 preparedStatement = con.prepareStatement(query);
			 preparedStatement.setInt(1, pid);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int a_id = myRs.getInt("A_ID");
				 int d_id = myRs.getInt("D_ID");
				 Date a_date = myRs.getDate("APP_DATE");
				 int a_time = myRs.getInt("APP_TIME");
				 int a_book = myRs.getInt("A_BOOKED");
				 
				 
				 Appointmentbean abean = new  Appointmentbean(d_id,a_date,a_time,a_id,a_book);

				 
				 al2.add(abean);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return al2;
		
	 }
	
	public void delete_Appointment(String theappid,int d_id)  {

		Connection myConn = null;
		PreparedStatement myStmt1 = null;
		
		try {
			int a_id = Integer.parseInt(theappid);
			myConn  = getConnection();	
			String sql = "delete from PG_APPOINTMENT_DEMO where A_ID=?";
			myStmt1 = myConn.prepareStatement(sql);
			myStmt1.setInt(1, a_id);
			boolean i=myStmt1.execute();
			System.out.println(i);
			myStmt1.close();
			 myConn.close();
		   }
		 catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	                                                }
		
}
