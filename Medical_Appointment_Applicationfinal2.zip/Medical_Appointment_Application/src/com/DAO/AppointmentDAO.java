package com.DAO;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.Bean.*;
import com.Bean.Doctor;
import com.ConnectionString.ConnectionString;

public class AppointmentDAO extends ConnectionString  {
	
	public String doctorAppointment(Appointmentbean appbean, int doc_id, String date)
	{
		try
		 {
	 int p_id=appbean.getP_id();
	
	 int d_id=appbean.getD_id();
	 Date ddate=appbean.getDate();
	 int time = appbean.getTime();
	 System.out.println("the time on the appointment dao is"+time);
	 int i=0;
      java.sql.Date sqlDate = new java.sql.Date(ddate.getTime());
	 
	 Connection con = null;
	 PreparedStatement preparedStatement = null;
	 con = getConnection();
	 int a_status=0;
	 String query3="select A_STATUS AS C from PG_DOCTOR_LEAVE where S_DATE<='"+date+"' AND E_DATE>='"+date+"'AND D_ID='"+doc_id+"'";
	 preparedStatement = con.prepareStatement(query3);
	 ResultSet rs3=preparedStatement.executeQuery(); 
	 while(rs3.next()){
		  a_status=rs3.getInt("C");
		 // a_status=rs1.getInt("A_STATUS");
		              }
	 
	 String query0="select COUNT(A_STATUS) AS C from PG_DOCTOR_LEAVE where S_DATE<='"+date+"' AND E_DATE>='"+date+"'AND D_ID='"+doc_id+"'";
	 preparedStatement = con.prepareStatement(query0);
	 int count=0;
	
	 ResultSet rs1=preparedStatement.executeQuery(); 
	 while(rs1.next()){
		  count=rs1.getInt("C");
		 // a_status=rs1.getInt("A_STATUS");
		              }
	 if(count==0 ||a_status==2||a_status==0)
	 {
	 String query1="select A_BOOKED  from PG_APPOINTMENT_DEMO where APP_DATE='"+date+"' AND APP_TIME='"+time+"' AND D_ID='"+doc_id+"'";
	 preparedStatement = con.prepareStatement(query1);
	 ResultSet rs=preparedStatement.executeQuery();
	 int book=0;
	 while(rs.next()){
	  book=rs.getInt("A_BOOKED");
	                 }
	 
	 if(book!=1)
	 {
	 String query2 = "insert into PG_APPOINTMENT_DEMO(D_ID,P_ID,APP_DATE,APP_TIME,A_BOOKED) values (?,?,?,?,1)"; //Insert user details into the table 'USERS'
	 preparedStatement = con.prepareStatement(query2); //Making use of prepared statements here to insert bunch of data
	 preparedStatement.setInt(1, doc_id);
	 preparedStatement.setInt(2, p_id);
	 preparedStatement.setDate(3, sqlDate);
	 preparedStatement.setInt(4, time);
	 i=preparedStatement.executeUpdate();
	 }
	 System.out.println("the value of i is"+i);
	 if(i!=0)
	 {
		 return "SUCCESS";
	 }
	 else
	 {
		 return "BOOKING NOT POSIBLE";
	 }
	 }
	 else
	 {
		 System.out.println("leave");
		 return "LEAVE";
	 }
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
		 
		
	 return "BOOKING NOT POSIBLE";
	}
	
	
	public List<Doctor> getDoctor() throws SQLException, FileNotFoundException  
	{
		List<Doctor> doc=new <Doctor>ArrayList();

		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		System.out.println("hello world");
			
		    con =getConnection();	
		    
		    
		    String query = "SELECT PG_DOCTOR_REG.D_ID AS D_ID, PG_DOCTOR_REG.D_NAME AS D_NAME FROM PG_DOCTOR_REG INNER JOIN PG_LOGIN ON PG_DOCTOR_REG.D_ID=PG_LOGIN.D_ID ";

  
			//String query = "select D_ID,D_NAME from PG_DOCTOR_REG";
			
			 preparedStatement = con.prepareStatement(query);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int id = myRs.getInt("D_ID");
				 String firstName = myRs.getString("D_NAME");
				
				 
				 
				 Doctor tempDoctor = new Doctor(id, firstName );

				 
				 doc.add(tempDoctor);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return doc;
		
	 }
	
	
	
	
}
