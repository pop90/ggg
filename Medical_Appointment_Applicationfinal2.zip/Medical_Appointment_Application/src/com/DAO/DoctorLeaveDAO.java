package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.Bean.Appointmentbean;
import com.Bean.Doctor;
import com.Bean.Leave;
import com.ConnectionString.ConnectionString;

public class DoctorLeaveDAO  extends ConnectionString{

	public String doctorLeave(Date start,Date end,String ds,String de,String reason,int doc_id)
	{
		try
		 {
	
	 int i=0;
      java.sql.Date sdate1 = new java.sql.Date(start.getTime());
      java.sql.Date sdate2 = new java.sql.Date(end.getTime());
	 Connection con = null;
	 PreparedStatement preparedStatement = null;
	 
	 con = getConnection();
	 String query1="select COUNT(*) AS c from PG_DOCTOR_LEAVE where ( S_DATE between '"+ds+"' and '"+de+"' OR E_DATE between '"+ds+"' and '"+de+"'  OR ( S_DATE < '"+ds+"' and '"+de+"' < E_DATE ))";
	 preparedStatement = con.prepareStatement(query1);
	 ResultSet rs=preparedStatement.executeQuery();
	 int count=0;
	 while(rs.next()){
	  count=rs.getInt("c");
	  System.out.println("the value of count is"+count);
	 }
	 
	 if(count==0)
	 {
	 String query2 = "insert into PG_DOCTOR_LEAVE(D_ID,A_STATUS,D_STATUS,REASON,S_DATE,E_DATE) values (?,2,1,?,?,?)"; //Insert user details into the table 'USERS'
	 preparedStatement = con.prepareStatement(query2); //Making use of prepared statements here to insert bunch of data
	 preparedStatement.setInt(1, doc_id);
	 preparedStatement.setString(2, reason);
	 preparedStatement.setDate(3, sdate1);
	 preparedStatement.setDate(4, sdate2);
	 i=preparedStatement.executeUpdate();
	 }
	 System.out.println("the value of i is"+i);
	 if(i!=0)
	 {
		 return "SUCCESS";
	 }
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
	 return "FAILED";
	}
	
	public List<Leave> getLeaveView(int did,String username) throws SQLException, FileNotFoundException  
	{
		List<Leave> lv=new <Leave>ArrayList();

		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
			System.out.println("2");
			
		    con = getConnection();	
			
			String query = " SELECT LE_ID,A_STATUS,REASON,S_DATE,E_DATE FROM PG_DOCTOR_LEAVE WHERE D_ID='"+did+"' AND S_DATE>SYSDATE";
			
			 preparedStatement = con.prepareStatement(query);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int le_id = myRs.getInt("LE_ID");
				 int a_stat = myRs.getInt("A_STATUS");
				 String reason = myRs.getString("REASON");
				 Date sd = myRs.getDate("S_DATE");
				 Date ed = myRs.getDate("E_DATE");
				
				 
				 System.out.println("3");
				 Leave dlv = new Leave(le_id,a_stat,reason,sd,ed);

				 
				 lv.add(dlv);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return lv;
		
	 }
	public void deleteLeave(String le_id,int d_id,String s_date,String e_date) throws FileNotFoundException {

		Connection myConn = null;
		PreparedStatement myStmt1 = null;
		
		try {
			
			int le_id1 = Integer.parseInt(le_id);
			
			
			myConn  = getConnection();	
			
			String sql1 = "UPDATE PG_APPOINTMENT_DEMO SET A_BOOKED=1 WHERE D_ID='"+d_id+"' AND APP_DATE>='"+s_date+"' AND APP_DATE<='"+e_date+"'";
			myStmt1 = myConn.prepareStatement(sql1);
			boolean f=myStmt1.execute();
			System.out.println("exe"+f);
			String sql = "delete from PG_DOCTOR_LEAVE where LE_ID=?";
			myStmt1 = myConn.prepareStatement(sql);
			myStmt1.setInt(1, le_id1);
			boolean i=myStmt1.execute();
			
			System.out.println("the value of i is :"+i);
			myStmt1.close();
			 myConn.close();
		}
		 catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
	}
		
	
	
	
	
}
