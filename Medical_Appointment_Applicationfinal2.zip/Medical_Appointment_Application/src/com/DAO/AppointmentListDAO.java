package com.DAO;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.ConnectionString.*;
import com.Interface.Appointment;
import com.Bean.*;

public class AppointmentListDAO extends ConnectionString implements Appointment {
	public List<Appointmentbean> getAppointment(int did) throws SQLException, FileNotFoundException  
	{
		List<Appointmentbean> al1=new <Appointmentbean>ArrayList();

		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		   // int d_id=Integer.parseInt(did);
			
		    con = getConnection();	
			
			String query = "SELECT A_ID,P_ID,APP_DATE,APP_TIME FROM PG_APPOINTMENT_DEMO WHERE D_ID=? AND APP_DATE>=SYSDATE ORDER BY APP_DATE,APP_TIME ASC";
			 
			 preparedStatement = con.prepareStatement(query);
			 preparedStatement.setInt(1, did);
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int a_id = myRs.getInt("A_ID");
				 int p_id = myRs.getInt("P_ID");
				 Date a_date = myRs.getDate("APP_DATE");
				 int a_time = myRs.getInt("APP_TIME");
				 
				 
				 
				 Appointmentbean abean = new  Appointmentbean(a_date,a_time,p_id,a_id);

				 
				 al1.add(abean);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return al1;
		
	 }
	public void delete_Appointment(String theappid,int p_id)  {

		Connection myConn = null;
		PreparedStatement myStmt1 = null;
		
		try {
			
			int a_id = Integer.parseInt(theappid);
			myConn  = getConnection();	
			String sql1 = "select P_EMAIL from PG_PATIENT_REG where P_ID='"+p_id+"'";
			myStmt1 = myConn.prepareStatement(sql1);
			ResultSet myRs=myStmt1.executeQuery();
			String mail="";
			 while (myRs.next()) {

				  mail = myRs.getString("P_EMAIL");
	
			                        }

			System.out.println(mail);
			
			String sql = "delete from PG_APPOINTMENT_DEMO where A_ID=?";
			myStmt1 = myConn.prepareStatement(sql);
			myStmt1.setInt(1, a_id);
			boolean i=myStmt1.execute();
			 AdminMailDAO a=new AdminMailDAO();
			 String subject="appointment cancelled";
			 String body="sorry to say that your appointment id of '"+theappid+"' is cancelled"; 
			
				a.sendEmail(subject,mail,mail,body);
			myStmt1.close();
			 myConn.close();
		   }
		 catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	                                                }
	
	public List<Appointmentbean> getAppHistory(int did,String sdate,String edate) throws SQLException, FileNotFoundException  
	{
		List<Appointmentbean> al2=new <Appointmentbean>ArrayList();

		 Connection con=null;
		PreparedStatement preparedStatement;
		
		try {
			
		   // int d_id=Integer.parseInt(did);
			
		    con = getConnection();	
			
			String query = "SELECT A_ID,P_ID,APP_DATE,APP_TIME FROM PG_APPOINTMENT_DEMO WHERE D_ID='"+did+"' AND APP_DATE BETWEEN '"+sdate+"' AND '"+edate+"' ORDER BY APP_DATE,APP_TIME ASC";
			 
			 preparedStatement = con.prepareStatement(query);

			 
			 ResultSet myRs=preparedStatement.executeQuery();
		
			 while (myRs.next()) {

				
				 int a_id = myRs.getInt("A_ID");
				 int p_id = myRs.getInt("P_ID");
				 Date a_date = myRs.getDate("APP_DATE");
				 int a_time = myRs.getInt("APP_TIME");
				 
				 
				 
				 Appointmentbean abean1 = new  Appointmentbean(a_date,a_time,p_id,a_id);

				 
				 al2.add(abean1);				
			                        }


			
			 myRs.close(); 
			 preparedStatement.close();
		}
		
		  catch(SQLException e)
		  {
		 e.printStackTrace();
			 
		  }
		finally
		{
			
			con.close();
		}
		return al2;	
		
		
		
	}
		
}
