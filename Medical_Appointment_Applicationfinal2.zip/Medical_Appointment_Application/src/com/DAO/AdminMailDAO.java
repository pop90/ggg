package com.DAO;

import java.util.Properties;


import javax.mail.*;
import javax.mail.internet.*;

public class AdminMailDAO {
	public void sendEmail(String tBSubject, String tBTo, String tBFrom, String tBBody)  throws AddressException,
    MessagingException{
                                
                      String host = "tmu-econ.mail.allianz";

                     
                      Properties properties = System.getProperties();

                     
                      properties.setProperty("mail.smtp.host", host);

                      
                      Session session = Session.getDefaultInstance(properties);

                      try {
                         
                         MimeMessage message = new MimeMessage(session);

                        
                         message.setFrom(new InternetAddress(tBFrom));

                         
                         message.addRecipient(Message.RecipientType.TO, new InternetAddress(tBTo));

                       
                         message.setSubject(tBSubject);

                         
                         message.setContent(tBBody, "text/html");


                        
                         Transport.send(message);
                         System.out.println("Sent message successfully....");
                      } catch (MessagingException mex) {
                         mex.printStackTrace();
                      }

                                
                }
	
	

}
