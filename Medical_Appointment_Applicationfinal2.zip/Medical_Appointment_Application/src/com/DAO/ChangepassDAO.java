package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Bean.Doctor;
import com.ConnectionString.ConnectionString;
import com.Interface.Changepass;
import com.Other.Encryption;

public class ChangepassDAO extends ConnectionString  implements Changepass{

	public String changePass1(int d_id,String opass,String npass) 
	 {
		 Encryption e1=new Encryption();
		String encpass=e1.caesarCipherEncrypt(opass);
		String nencpass=e1.caesarCipherEncrypt(npass);
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 try
		 {
			
		 con = getConnection();
		 String query = "UPDATE PG_LOGIN SET PASSWORD='"+nencpass+"' WHERE D_ID='"+d_id+"' AND PASSWORD='"+encpass+"'"; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 
		 int i= preparedStatement.executeUpdate();
		 System.out.println("the changed password is"+i);
		 if (i!=0)  //Just to ensure data has been inserted into the database
		return "SUCCESS";
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
			 
		 } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 return "something went wrong";  // On failure, send a message from here.

	 }

}
