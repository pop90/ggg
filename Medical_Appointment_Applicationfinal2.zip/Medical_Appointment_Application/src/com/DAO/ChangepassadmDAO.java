package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ConnectionString.ConnectionString;
import com.Interface.Changepass;
import com.Other.Encryption;

public class ChangepassadmDAO extends ConnectionString  implements Changepass{
	public String changePass1(int ad_id,String opass,String npass) 
	 {
		 
		
		
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 try
		 {
			 Encryption e=new Encryption();
			 
			 String encpass=e.caesarCipherEncrypt(opass);
			 String nencpass=e.caesarCipherEncrypt(npass);
		 con = getConnection();
		 String query = "UPDATE PG_LOGIN SET PASSWORD='"+nencpass+"' WHERE AD_ID='"+ad_id+"'AND PASSWORD='"+encpass+"' "; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		 
		 int i= preparedStatement.executeUpdate();
		 System.out.println("the changed password is"+i);
		 if (i!=0)  
		return "SUCCESS";
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
			
		 } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 return "something went wrong"; 

	 }

	
	


}
