package com.DAO;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ConnectionString.ConnectionString;
import com.Interface.Changepass;
import com.Other.Encryption;

public class ChangepasspatDAO extends ConnectionString implements Changepass {
	
	public String changePass1(int p_id,String opass,String npass)
	 {
		 
		
		Encryption e1=new Encryption();
		 Connection con = null;
		 PreparedStatement preparedStatement = null;
		 String nencpass=e1.caesarCipherEncrypt(npass);
		 try
		 {
			 String encpass=e1.caesarCipherEncrypt(opass);
		 con = getConnection();
		 String query = "UPDATE PG_LOGIN SET PASSWORD='"+nencpass+"' WHERE P_ID='"+p_id+"' AND PASSWORD='"+encpass+"' "; //Insert user details into the table 'USERS'
		 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
		
		 int i= preparedStatement.executeUpdate();
		 System.out.println("the changed password is"+i);
		 if (i!=0)  //Just to ensure data has been inserted into the database
		return "SUCCESS";
		 }
		 catch(SQLException e)
		 {
		 e.printStackTrace();
			
		 } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 return "something went wrong";  // On failure, send a message from here.

	 }


}
