package com.Bean;

public class Doctor {
	private int id;
	private String username;
	private String password;
	private String email;
	private String department;
	private String gender;
	private String phone;
	private String address;
	private String doctor_name;
	
	
	public Doctor() {

	}
	public Doctor(int id, String doctor_name, String username, String password, String email, String department,
			String gender, String phone, String address) {
		super();
		this.id = id;
		this.doctor_name = doctor_name;
		this.username = username;
		this.password = password;
		this.email = email;
		this.department = department;
		this.gender = gender;
		this.phone = phone;
		this.address = address;
	}
	
	
	public Doctor(int id, String doctor_name, String department, String username, String password) {
		super();
		this.id = id;
		this.doctor_name = doctor_name;
		this.username = username;
		this.password = password;
		this.department = department;
	}
	
	
	
	
	
	public Doctor(String email, String department, String gender, String phone, String address, String doctor_name) {
		super();
		this.email = email;
		this.department = department;
		this.gender = gender;
		this.phone = phone;
		this.address = address;
		this.doctor_name = doctor_name;
	}
	public Doctor(int id, String doctor_name) {
		super();
		this.id = id;
		this.doctor_name = doctor_name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	

	

	
	
	
	

}
