package com.Bean;

import java.util.Date;

public class Leave {
	private int le_id;
	private int d_id;
	private int a_status;
	private int d_status;
	private String reason;
	private Date  s_date;
	private Date e_date;
	
	public Leave() {
		
	}
	
	
	
	public Leave(int lE_ID, int a_STATUS, String rEASON, Date s_DATE, Date e_DATE) {
		
		le_id = lE_ID;
		a_status= a_STATUS;
		reason = rEASON;
		s_date = s_DATE;
		e_date = e_DATE;
	}



	public Leave(int le_id, int d_id, int d_status, String reason, Date s_date, Date e_date,int a_status) {
		super();
		this.le_id = le_id;
		this.d_id = d_id;
		this.d_status = d_status;
		this.reason = reason;
		this.s_date = s_date;
		this.e_date = e_date;
		this.a_status=a_status;
	}



	public int getLe_id() {
		return le_id;
	}



	public void setLe_id(int le_id) {
		this.le_id = le_id;
	}



	public int getD_id() {
		return d_id;
	}



	public void setD_id(int d_id) {
		this.d_id = d_id;
	}



	public int getA_status() {
		return a_status;
	}



	public void setA_status(int a_status) {
		this.a_status = a_status;
	}



	public int getD_status() {
		return d_status;
	}



	public void setD_status(int d_status) {
		this.d_status = d_status;
	}



	public String getReason() {
		return reason;
	}



	public void setReason(String reason) {
		this.reason = reason;
	}



	public Date getS_date() {
		return s_date;
	}



	public void setS_date(Date s_date) {
		this.s_date = s_date;
	}



	public Date getE_date() {
		return e_date;
	}



	public void setE_date(Date e_date) {
		this.e_date = e_date;
	}
	
	

}
