package com.ConnectionString;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

 public abstract class ConnectionString {

  //private static Connection con;
   
    
    
    public  Connection getConnection() throws FileNotFoundException {
        try {
        	
        	Properties property = new Properties();
        	InputStream input = null;
        	input = new FileInputStream("C:/Users/T10332/AppData/Local/Microsoft/AppV/Client/VFS/90B8D7B1-368D-4EBE-8FEC-B8CC5F96F03B/Profile/workspace/Medical_Appointment_Application/connection.properties");
        	
                property.load(input);
                input.close();
          

        	
            Class.forName(property.getProperty("ojdbc.driver"));
           
         
           Connection con = DriverManager.getConnection(property.getProperty("ojdbc.url"), property.getProperty("ojdbc.username"),property.getProperty("ojdbc.password"));
            	
           return con;
        } catch (ClassNotFoundException ex) {
            
            System.out.println("Driver not found."); 
        }
        catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
                                 }
        catch (SQLException ex) {
            
            System.out.println("Failed to create the database connection."); 
        }
        return null;
    }


}
