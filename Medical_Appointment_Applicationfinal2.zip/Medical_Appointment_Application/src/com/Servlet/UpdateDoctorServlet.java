package com.Servlet;

import java.io.IOException;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.Doctor;
import com.DAO.DoctorregDAO;

/**
 * Servlet implementation class UpdateDoctorServlet
 */
@WebServlet("/UpdateDoctorServlet")
public class UpdateDoctorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDoctorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		response.setHeader("Cache-Control","no-cache"); 
        response.setHeader("Cache-Control","no-store"); 
        response.setDateHeader("Expires", 100); 
        response.setHeader("Pragma","no-cache");
        String username=(String)session.getAttribute("DOCTOR");
        int d_id=(int)session.getAttribute("d_id");
        if (null == username) {
                     request.setAttribute("Error", "Session has ended.  Please login.");
                       request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                            }
    	
		String action = request.getParameter("update");
		
		if(action==null)
		{
			try {
				listDoc(request,response,d_id);
			    } 
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			                        }
		}
		else if(action.equals("update") && action!=null)
		{
			updateDoc(request,response,d_id);	
		}
			
	}
	
	private void updateDoc(HttpServletRequest request, HttpServletResponse response,int d_id) throws ServletException, IOException 
	{
		try {
			
			 Doctor doctorreg=new Doctor();		
			//Copying all the input parameters in to local variables
			 String firstName = request.getParameter("name");
			 String address = request.getParameter("address");
			 String gender = request.getParameter("gender");
			 String department = request.getParameter("department");
			 String email = request.getParameter("mail");
			 String phoneNumber = request.getParameter("phone");
			
			 
			//set value into bean
			 doctorreg.setDoctor_name(firstName);
			 doctorreg.setAddress(address);
			 doctorreg.setEmail(email);
			 doctorreg.setDepartment(department);
			 doctorreg.setGender(gender);
			 doctorreg.setPhone(phoneNumber);
			 doctorreg.setId(d_id);
			
			 DoctorregDAO doctorregdao=new DoctorregDAO();
			 String userRegistered;
			 
			 
			 
                      List<Doctor> lvd= doctorregdao.listDoctor(d_id);
					  userRegistered = doctorregdao.doctorUpdate(doctorreg);			
					 
			   
			 
			 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
			 {
				 
				 
				 request.setAttribute("msg","success");
				  request.setAttribute("doc", lvd);
			 request.getRequestDispatcher("/UpdateDoctor.jsp").include(request, response);

			 }
		 
			 else                      //On Failure, display a meaningful message to the User.
			 {

				 request.setAttribute("msg", "not success");
				  request.setAttribute("doc", lvd);
				 request.getRequestDispatcher("/UpdateDoctor.jsp").include(request, response);

			 }
			  } catch (SQLException e) {
				// TODO Auto-generated catch block
			 	e.printStackTrace();
			                            }
			
	   }
	
	
	
	private void listDoc(HttpServletRequest request, HttpServletResponse response,int d_id) throws ServletException, IOException, SQLException
	{
		
		  DoctorregDAO doctorregdao=new DoctorregDAO();
		  List<Doctor> lvd= doctorregdao.listDoctor(d_id);
		  request.setAttribute("doc", lvd);
		  request.getRequestDispatcher("/UpdateDoctor.jsp").include(request, response);
		
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
