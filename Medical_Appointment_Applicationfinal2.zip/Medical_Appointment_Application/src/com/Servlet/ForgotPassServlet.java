package com.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Bean.ForgPass;
import com.DAO.AdminMailDAO;
import com.DAO.ForgPassDAO;

/**
 * Servlet implementation class ForgotPassServlet
 */
@WebServlet("/ForgotPassServlet")
public class ForgotPassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgotPassServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			response.setHeader("Cache-Control","no-cache"); 
            response.setHeader("Cache-Control","no-store"); 
           response.setDateHeader("Expires", 0); 
           response.setHeader("Pragma","no-cache");
			
			
		ForgPassDAO fp=new ForgPassDAO();
		 String email = request.getParameter("mail");
		 String type = request.getParameter("type");
		 int type1=Integer.parseInt(type);
		 String username="";
		 String password="";
	   String subject="username and password";
			List<ForgPass> f=fp.getPass(type1,email);
			for(ForgPass c:f)
			{
				username=c.getUsername();
				password=c.getPassword();
			}
			AdminMailDAO a=new AdminMailDAO();
			 String from=email;
			 String body="the username is:'"+username+"' and password is:'"+password+"'";
			a.sendEmail(subject,email,from,body);
			request.setAttribute("msg","mail send successfully");
			request.getRequestDispatcher("Forgotpass.jsp").forward(request, response);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
