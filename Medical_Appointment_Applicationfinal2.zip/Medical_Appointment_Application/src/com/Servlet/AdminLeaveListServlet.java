package com.Servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.Leave;
import com.DAO.AdminLeave;
import com.DAO.DoctorLeaveDAO;

/**
 * Servlet implementation class AdminLeaveListServlet
 */
@WebServlet("/AdminLeaveListServlet")
public class AdminLeaveListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLeaveListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			HttpSession session = request.getSession();
			response.setHeader("Cache-Control","no-cache"); 
            response.setHeader("Cache-Control","no-store"); 
           response.setDateHeader("Expires", 0); 
           response.setHeader("Pragma","no-cache");
           String username=(String)session.getAttribute("ADMIN");
           if (null == username) {
               request.setAttribute("Error", "Session has ended.  Please login.");
                request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                        }
			
			String action = request.getParameter("action");
			
	        if(action==null)
	        {
		
			listLeave(request, response);
		
	         }
	       else if(action.equals("cancel") && action!=null)
	         {
	     cancelLeave(request,response);	
	          }
	       else 
	         {
	   System.out.println("else case servlet accept");
	     acceptLeave(request,response);	
	     
	          }
					
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	private void listLeave(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		 
			AdminLeave al=new AdminLeave();
			
			List<Leave> lv = al.getLeaveView();
			System.out.println("4");
			
			 request.setAttribute("ADMIN_LEAVE_LIST",lv);
			 request.getRequestDispatcher("/Admin_Leave_List.jsp").forward(request, response);
		}
	private void cancelLeave(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		      AdminLeave al=new AdminLeave();

			String le_id = request.getParameter("le_id");
		
			   al.cancelLeave(le_id);
					
			listLeave(request, response);
		}
	private void acceptLeave(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		      AdminLeave al=new AdminLeave();

			String le_id = request.getParameter("le_id");
			String d_id = request.getParameter("d_id");
			String s_date = request.getParameter("s_date");
			String e_date = request.getParameter("e_date");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
    System.out.println("servlet accept");
			
				Date dt = sdf.parse(s_date);
				String dy=format2.format(dt);
				
				Date dt1= sdf.parse(e_date);
				String dy1=format2.format(dt1);
				
			   al.acceptLeave(le_id,d_id,dy,dy1);
					
			listLeave(request, response);
		}
	
	
	
}
