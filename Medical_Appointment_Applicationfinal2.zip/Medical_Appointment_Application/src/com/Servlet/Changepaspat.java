package com.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.ChangepassDAO;
import com.DAO.ChangepasspatDAO;

/**
 * Servlet implementation class Changepaspat
 */
@WebServlet("/Changepaspat")
public class Changepaspat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Changepaspat() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		
		
		response.setHeader("Cache-Control","no-cache"); 
        response.setHeader("Cache-Control","no-store"); 
        response.setDateHeader("Expires", 0); 
        response.setHeader("Pragma","no-cache");
		
        String username=(String)session.getAttribute("PATIENT");
        if (null == username) {
            request.setAttribute("Error", "Session has ended.  Please login.");
             request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                     }
		
		
		int p_id=(int)session.getAttribute("id");
		String oldpass=request.getParameter("password");
		String newpass=request.getParameter("re-pass1");
		ChangepasspatDAO c=new ChangepasspatDAO();
		String result=c.changePass1(p_id,oldpass,newpass);
		if(result.equals("SUCCESS"))
		{
			request.setAttribute("msg4", "password changed successfully");
			request.getRequestDispatcher("Changepasspat.jsp").forward(request, response);
		}
		else
		{
			request.setAttribute("msg4", "password change failed");
			request.getRequestDispatcher("Changepasspat.jsp").forward(request, response);
			
		}
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
