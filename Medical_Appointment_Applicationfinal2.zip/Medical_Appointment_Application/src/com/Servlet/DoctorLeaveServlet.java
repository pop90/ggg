package com.Servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.DoctorLeaveDAO;

/**
 * Servlet implementation class DoctorLeaveServlet
 */
@WebServlet("/DoctorLeaveServlet")
public class DoctorLeaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorLeaveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
		    HttpSession session = request.getSession();
		    response.setHeader("Cache-Control","no-cache"); 
            response.setHeader("Cache-Control","no-store"); 
           response.setDateHeader("Expires", 0); 
           response.setHeader("Pragma","no-cache");
           String username=(String)session.getAttribute("DOCTOR");
           if (null == username) {
               request.setAttribute("Error", "Session has ended.  Please login.");
                request.getRequestDispatcher("/login_page.jsp").forward(request, response);
     }
		    int did=(int)session.getAttribute("d_id");
		    String da=request.getParameter("date1");
		    String da2=request.getParameter("date2");
		    String rs=request.getParameter("Reason");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
				DoctorLeaveDAO d=new DoctorLeaveDAO();
				Date dt = sdf.parse(da);	
				String dy=format2.format(dt);
				Date dte=format2.parse(dy);
				
				Date dt1 = sdf.parse(da2);	
				String dy1=format2.format(dt1);
				Date dte1=format2.parse(dy1);
		
		        String result=d.doctorLeave(dte,dte1,dy,dy1,rs,did);
		        if(result.equals("SUCCESS")) 
				{ 
					  request.setAttribute("msg9", "success");
					request.getRequestDispatcher("DoctorLeave.jsp").forward(request, response);
				}
		        else 
				{ 
					  request.setAttribute("msg9", "failed");
					request.getRequestDispatcher("DoctorLeave.jsp").forward(request, response);
				}
		         
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
