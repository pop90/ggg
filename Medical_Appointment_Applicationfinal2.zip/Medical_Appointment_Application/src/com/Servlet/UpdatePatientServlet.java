package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.PatientRegBean;
import com.DAO.PatientregDAO;

/**
 * Servlet implementation class UpdatePatientServlet
 */
@WebServlet("/UpdatePatientServlet")
public class UpdatePatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePatientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
		
		HttpSession session = request.getSession();
		response.setHeader("Cache-Control","no-cache"); 
        response.setHeader("Cache-Control","no-store"); 
       response.setDateHeader("Expires", 0); 
       response.setHeader("Pragma","no-cache");
        String username=(String)session.getAttribute("PATIENT");
    if (null == username) {
                 request.setAttribute("Error", "Session has ended.  Please login.");
                   request.getRequestDispatcher("/login_page.jsp").forward(request, response);

    }
		
		PatientRegBean objbean=new PatientRegBean();
		
		String firstName = request.getParameter("name");
		 String address = request.getParameter("address");
		 String gender = request.getParameter("gender");
		 String email = request.getParameter("mail");
		 String phoneNumber = request.getParameter("phone");
		 int p_id=(int)session.getAttribute("id");
		 
		 
		 objbean.setName(firstName);
		 objbean.setAddress(address);
		 objbean.setMail(email);
		 objbean.setGender(gender);
		 objbean.setPhone(phoneNumber);
		 objbean.setId(p_id);
		
		 
		  PatientregDAO objdao=new PatientregDAO();
          String userRegistered;
		
			userRegistered = objdao.patientUpdate(objbean);
		
		 
		 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
			
			 request.setAttribute("msg", "Updated successfully");
			 request.getRequestDispatcher("/UpdatePatient.jsp").include(request, response);

		 }
		
		 else   //On Failure, display a meaningful message to the User.
		 {
			 request.setAttribute("msg", "Updation is not success");
			 request.getRequestDispatcher("/UpdatePatient.jsp").include(request, response);

		 }
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
