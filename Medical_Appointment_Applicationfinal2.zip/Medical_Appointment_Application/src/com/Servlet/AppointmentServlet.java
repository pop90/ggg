package com.Servlet;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;

import com.Bean.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.*;
/**
 * Servlet implementation class AppointmentServlet
 */
@WebServlet("/AppointmentServlet")
public class AppointmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  		// TODO Auto-generated method stub
  		//response.getWriter().append("Served at: ").append(request.getContextPath());
  		doPost(request,response);
  	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		response.setHeader("Cache-Control","no-cache"); 
        response.setHeader("Cache-Control","no-store"); 
        response.setDateHeader("Expires", 0); 
        response.setHeader("Pragma","no-cache");
       String username=(String)session.getAttribute("PATIENT");
        int p_id=(int)session.getAttribute("id");
   if (null == username) {
                  request.setAttribute("Error", "Session has ended.  Please login.");
                   request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                           }
		 AppointmentDAO appdao=new AppointmentDAO();
		 Appointmentbean appbean=new Appointmentbean();
		
		
		System.out.println("the value of pid is"+p_id);
		LoginBean pbean=new LoginBean();
		PrintWriter out = response.getWriter();
		try {
		//int p_id=Integer.parseInt(pid);
		//System.out.println("the p_id is"+pid);
		String did=request.getParameter("doctor");
		int d_id=Integer.parseInt(did);
		String da=request.getParameter("date");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");

		
			Date dt = sdf.parse(da);
			String dy=format2.format(dt);
			Date dte=format2.parse(dy);
			System.out.println("the date is "+dy);
			appbean.setDate(dte);
	
		String time=request.getParameter("time");
		int time1=Integer.parseInt(time);

		appbean.setD_id(d_id);
		appbean.setP_id(p_id);
		
		appbean.setTime(time1);
		
		 String appointment = appdao.doctorAppointment(appbean,d_id,dy);
		 
		
		 if(appointment.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {  
			    request.setAttribute("msg2", "success");
				request.getRequestDispatcher("/DoctorDetailsServlet").include(request, response);
			//request.getRequestDispatcher("/Appointment_page.jsp").include(request, response);
//			 out.print("<html><body>");  
//	         out.println("<script type=\"text/javascript\">");
//	         out.println("alert('success');");
//	         out.println("</script>");
//	         out.print("</body></html>");
//	         out.close(); 
		 }
		 else if(appointment.equals("LEAVE"))  //On Failure, display a meaningful message to the User.
		 {
			    request.setAttribute("msg2", "doctor is leave");
				request.getRequestDispatcher("/DoctorDetailsServlet").include(request, response);
			 //request.getRequestDispatcher("/Appointment_page.jsp").include(request, response);
//			 out.print("<html><body>");  
//	         out.println("<script type=\"text/javascript\">");
//	         out.println("alert('already booked');");
//	         out.println("</script>");
//	         out.print("</body></html>");
//	         out.close(); 
		 }
		 else
		 {
			 request.setAttribute("msg2", "already booked");
				request.getRequestDispatcher("/DoctorDetailsServlet").include(request, response);
		 }
	}
		 catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}
