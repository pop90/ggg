package com.Servlet;
import com.DAO.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.*;


/**
 * Servlet implementation class DoctorLeaveListServlet
 */
@WebServlet("/DoctorLeaveListServlet")
public class DoctorLeaveListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorLeaveListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			HttpSession session = request.getSession();
			response.setHeader("Cache-Control","no-cache"); 
            response.setHeader("Cache-Control","no-store"); 
           response.setDateHeader("Expires", 0); 
           response.setHeader("Pragma","no-cache");	
           String username=(String)session.getAttribute("DOCTOR");
           if (null == username) {
                         request.setAttribute("Error", "Session has ended.  Please login.");
                          request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                                  }
			
		       String action = request.getParameter("action");
		
		        if(action==null)
		        {
			
				listLeave(request, response);
			
		         }
		       else if(action.equals("cancel") && action!=null)
		         {
		  deleteLeave(request,response);	
		          }
	        }
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		                    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	private void listLeave(HttpServletRequest request, HttpServletResponse response) 
			throws Exception {
		  HttpSession session = request.getSession();
			DoctorLeaveDAO dl=new DoctorLeaveDAO();
			int did=(int)session.getAttribute("d_id");
			String username=(String)session.getAttribute("DOCTOR");
			List<Leave> lv = dl.getLeaveView(did,username);
			System.out.println("1");
			for(Leave l:lv)
			{
				System.out.println("the reason is:"+l.getReason());
			}
			 request.setAttribute("DOCTOR_LEAVE_LIST",lv);
			 request.getRequestDispatcher("/Doctor_Leave_List.jsp").forward(request, response);
		}
	private void deleteLeave(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session = request.getSession();
		      DoctorLeaveDAO dl=new DoctorLeaveDAO();
		      int did=(int)session.getAttribute("d_id");
			
			String le_id = request.getParameter("le_id");
		
			 String s_date = request.getParameter("s_date");
			 String e_date = request.getParameter("e_date");
			 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			 SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");

				
					Date dt = sdf.parse(s_date);
					String sd=format2.format(dt);
					
					Date dt1 = sdf.parse(e_date);
					String ed=format2.format(dt1);
			
			   dl.deleteLeave(le_id,did,sd,ed);
			
			
			listLeave(request, response);
		}

}
