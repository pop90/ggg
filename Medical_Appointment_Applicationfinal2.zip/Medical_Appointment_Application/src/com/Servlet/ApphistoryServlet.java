package com.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.Appointmentbean;
import com.DAO.AppointmentListDAO;

/**
 * Servlet implementation class ApphistoryServlet
 */
@WebServlet("/ApphistoryServlet")
public class ApphistoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApphistoryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
		HttpSession session = request.getSession();
		response.setHeader("Cache-Control","no-cache"); 
        response.setHeader("Cache-Control","no-store"); 
        response.setDateHeader("Expires", 0); 
        response.setHeader("Pragma","no-cache");
        String username=(String)session.getAttribute("DOCTOR");
    if (null == username) {
                  request.setAttribute("Error", "Session has ended.  Please login.");
                   request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                           }
    int   did=(int)session.getAttribute("d_id");
    String da1=request.getParameter("date1");
    String da2=request.getParameter("date2");
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
	Date dt;
	Date dt2;
		dt = sdf.parse(da1);
	String dy1=format2.format(dt);
	dt2 = sdf.parse(da2);
	String dy2=format2.format(dt2);
	AppointmentListDAO al=new AppointmentListDAO();
	List<Appointmentbean> app1 = al.getAppHistory(did,dy1,dy2);

	 request.setAttribute("APPOINTMENT_HISTORY_LIST", app1);
	 request.getRequestDispatcher("AppointmentHistorySearch.jsp").forward(request, response);
	
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		                             }
		catch(SQLException e)
		{
			System.out.println("sql exception has occured");
		}
    
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
