package com.Servlet;
import com.DAO.*;
import com.Bean.*;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DoctorRegistrationServlet
 */
@WebServlet("/DoctorRegistrationServlet")
public class DoctorRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		HttpSession session = request.getSession();
		response.setHeader("Cache-Control","no-cache"); 
        response.setHeader("Cache-Control","no-store"); 
        response.setDateHeader("Expires", 100); 
        response.setHeader("Pragma","no-cache");
        String username=(String)session.getAttribute("ADMIN");
        if (null == username) {
                     request.setAttribute("Error", "Session has ended.  Please login.");
                       request.getRequestDispatcher("/login_page.jsp").forward(request, response);
                            }
		 Doctor doctorreg=new Doctor();
		 PrintWriter out = response.getWriter();
		//Copying all the input parameters in to local variables
		 String firstName = request.getParameter("name");
		 String address = request.getParameter("address");
		 String gender = request.getParameter("gender");
		 String department = request.getParameter("department");
		 String email = request.getParameter("mail");
		 String phoneNumber = request.getParameter("phone");
		 String userName = request.getParameter("username");
		 String password = request.getParameter("password");
		 
		//set value into bean
		 doctorreg.setDoctor_name(firstName);
		 doctorreg.setAddress(address);
		 doctorreg.setEmail(email);
		 doctorreg.setDepartment(department);
		 doctorreg.setGender(gender);
		 doctorreg.setPhone(phoneNumber);
		 doctorreg.setUsername(userName);
		 doctorreg.setPassword(password); 
		 DoctorregDAO doctorregdao=new DoctorregDAO();
		 String userRegistered = doctorregdao.doctorRegister(doctorreg);
		 
		 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
			 
			 request.setAttribute("msg3","success");
		 request.getRequestDispatcher("/doctor_registration_form.jsp").include(request, response);
//		 out.print("<html><body>");  
//         out.println("<script type=\"text/javascript\">");
//         out.println("alert('registered successfully');");
//         out.println("</script>");
//         out.print("</body></html>");
//         out.close(); 
		 }
		 else if(userRegistered.equals("UAT"))
		 {
			 request.setAttribute("msg3","username is already taken");
			 request.getRequestDispatcher("/doctor_registration_form.jsp").include(request, response);
		 }
			 
		 else   //On Failure, display a meaningful message to the User.
		 {

			 request.setAttribute("msg3", "not success");
			 request.getRequestDispatcher("/doctor_registration_form.jsp").include(request, response);
//			 out.print("<html><body>");  
//	         out.println("<script type=\"text/javascript\">");
//	         out.println("alert('registration not success');");
//	         out.println("</script>");
//	         out.print("</body></html>");
//	         out.close(); 
		 }
		 
	}

}
